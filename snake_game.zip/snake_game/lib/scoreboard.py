from food import Food
ALLIGNMENT = "center"
FONT = ("courier", 20, "normal")


class ScoreBoard(Food):

    def __init__(self):
        super().__init__()
        self.score = 0
        self.hideturtle()
        self.color("white")
        self.setpos(0, 276)
        self.update_score()

    def update_score(self):
        self.write(arg=f"Score: {self.score} ", align=ALLIGNMENT, font=FONT)

    def gameover(self):
        self.goto(0, 0)
        self.write("Game Over!", align=ALLIGNMENT, font=FONT)

    def increase_score(self):
        self.score += 1
        self.clear()
        self.update_score()






